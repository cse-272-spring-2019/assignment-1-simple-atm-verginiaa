package view;

import javafx.scene.layout.GridPane;

public class StartMenu extends GridPane {

    /*public StartMenu(){

        login.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                boolean isValid = validate(passwordField.getText());
                if(isValid){
                    MainMenu mainMenu = new MainMenu();


                }

            }
        });
    }

   //public boolean validate(String cardNr){

    //}*/
}
